# Author: John A. Cameron
# Date Created (DD/MM/YYYY): 22/08/2025
# For PSS/E 36.2 - IEEE 14-Bus Analysis
# Python code to automatically trip all 20 transmission lines for N-1 contingency analysis

import psspy

# Must first get the list of all non-transformer branches (from bus i, to bus j) in the model
# Can neglect the character "ID" as no 2 branches are connected by more than one branch

sid = -1
owner = -1
ties = -1
flag = 2
entry = 1
string = ["FROMNUMBER", "TONUMBER"]
ierr, iarray = psspy.abrnint(sid, owner, ties, flag, entry, string)


# The list of transmission lines (non-transformer) is stored as a 2x17 array [[i1, i2, ...], [j1, j2, ...]]
# Can now do the following: 1) Disable a branch, 2) Solve case, 3) Save results to a seperate .sav file, 4) Reactivate the branch

for i in range(17):
    ibus = iarray[0][i]
    jbus = iarray[1][i]
    ckt = "1"
    dr = psspy.getdefaultreal() # tells PSS/E not to change the value in my .sav file

    branch_status = 0

    intgar = [branch_status, ibus, 1, 0, 0, 0, 0]
    realar = [dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr]
    ratings = [dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr]
    namear = ""

    ierr = psspy.branch_chng_4(ibus, jbus, ckt, intgar, realar, ratings, namear)

    flat_start = 1 # flat start = est. 0 phase for all buses
    options = [0, 0, 0, 1, 1, flat_start, 99, 0]
    ierr = psspy.fdns(options)

    flat_start = 0 # do not flat start now
    options = [0, 0, 0, 1, 1, flat_start, 99, 0]
    ierr = psspy.fdns(options)

    # generate a .sav file: BranchitojOffline.sav

    if ierr == 0: # generate the .sav case
        casename = f"Branch{ibus}to{jbus}Offline.sav"
        ierr = psspy.save(casename)

        # get maximum machine loading
        sid = -1
        flag = 4
        string = "PERCENT"
        ierr, rarray = psspy.amachreal(sid, flag, string)
        max_machine_loading = max(rarray[0])

        # get maximum line loading
        sid = -1
        owner = -1
        ties = -1
        flag = 2
        entry = 1
        string = ["PCTMVARATEA"]
        ierr, rarray = psspy.abrnreal(sid, owner, ties, flag, entry, string)
        max_line_loading = max(rarray[0])

        # get maximum and minimum bus voltages
        sid = -1
        flag = 2
        string = ["PU"]
        ierr, rarray = psspy.abusreal(sid, flag, string)
        max_bus_voltage = max(rarray[0])
        min_bus_voltage = min(rarray[0])

        # push all data to the .txt file
        with open("branch_outage_summary.txt", "a") as f:
            f.write(f"For the line outage between Bus {ibus} and {jbus}:\n")
            f.write(f"Max Gen Loading: {max_machine_loading}%\n")
            f.write(f"Max Line Loading: {max_line_loading}%\n")
            f.write(f"Max Bus Voltage: {max_bus_voltage} p.u.\n")
            f.write(f"Min Bus Voltage: {min_bus_voltage} p.u.\n")
            f.write("-" * 40 + "\n")

    branch_status = 1 # bring branch back to service

    intgar = [branch_status, ibus, 1, 0, 0, 0, 0]
    realar = [dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr]
    ratings = [dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr]
    namear = ""

    ierr = psspy.branch_chng_4(ibus, jbus, ckt, intgar, realar, ratings, namear)

# must now repeat the process for all 2-winding transformer branches

sid = -1
owner = -1
ties = -1
flag = 6 # all 2-winding transformers
entry = 1
string = ["FROMNUMBER", "TONUMBER"]
ierr, iarray = psspy.abrnint(sid, owner, ties, flag, entry, string)

for i in range(3):
    ibus = iarray[0][i]
    jbus = iarray[1][i]
    ckt = "1"
    dr = psspy.getdefaultreal() # tells PSS/E not to change the value in my .sav file
    di = psspy.getdefaultint()

    branch_status = 0

    intgar = [branch_status, ibus, 1, 0, 0, 0, di, di, di, di, di, di, di, di, di, di]
    realari = [dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr]
    ratings = [dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr]
    namear = ""
    vgrpar = ""

    ierr, realaro = psspy.two_winding_chng_6(ibus, jbus, ckt, intgar, realari, ratings, namear, vgrpar)

    flat_start = 1 # flat start = est. 0 phase for all buses
    options = [0, 0, 0, 1, 1, flat_start, 99, 0]
    ierr = psspy.fdns(options)

    flat_start = 0 # do not flat start now
    options = [0, 0, 0, 1, 1, flat_start, 99, 0]
    ierr = psspy.fdns(options)

    if ierr == 0: # generate the .sav case
        casename = f"Transformer{ibus}to{jbus}Offline.sav"
        ierr = psspy.save(casename)

        # get maximum machine loading
        sid = -1
        flag = 4
        string = "PERCENT"
        ierr, rarray = psspy.amachreal(sid, flag, string)
        max_machine_loading = max(rarray[0])

        # get maximum line loading
        sid = -1
        owner = -1
        ties = -1
        flag = 2
        entry = 1
        string = ["PCTMVARATEA"]
        ierr, rarray = psspy.abrnreal(sid, owner, ties, flag, entry, string)
        max_line_loading = max(rarray[0])

        # get maximum and minimum bus voltages
        sid = -1
        flag = 2
        string = ["PU"]
        ierr, rarray = psspy.abusreal(sid, flag, string)
        max_bus_voltage = max(rarray[0])
        min_bus_voltage = min(rarray[0]) 

        # push all data to the .txt file
        with open("branch_outage_summary.txt", "a") as f:
            f.write(f"For the transformer outage between Bus {ibus} and {jbus}:\n")
            f.write(f"Max Gen Loading: {max_machine_loading}%\n")
            f.write(f"Max Line Loading: {max_line_loading}%\n")
            f.write(f"Max Bus Voltage: {max_bus_voltage} p.u.\n")
            f.write(f"Min Bus Voltage: {min_bus_voltage} p.u.\n")
            f.write("-" * 40 + "\n")

    branch_status = 1

    intgar = [branch_status, ibus, 1, 0, 0, 0, di, di, di, di, di, di, di, di, di, di]
    realari = [dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr]
    ratings = [dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr, dr]
    namear = ""
    vgrpar = ""

    ierr, realaro = psspy.two_winding_chng_6(ibus, jbus, ckt, intgar, realari, ratings, namear, vgrpar)

# End of script