# Author: John A. Cameron
# Date Created (DD/MM/YYYY): 17/08/2025
# For PSS/E 36.2 - IEEE 14-Bus Analysis
# Python code to generate the modified_ieee14bus.sav from ieee14bus.sav

import psspy

# Task 1: add shunt capacitors to buses 2 and 13

ibus = 2 # distributed bus with high Q_loaing
id = "1" # no buses will have more than 1 shunt
status = 1 # all shunts operational
shunt_admittance_arr = [0.0,19.0] # [G,B], Bus 2 shunt can supply 19 MVAR of Q
ierr =  psspy.shunt_data(ibus, id, [status], shunt_admittance_arr) # call psspy library function

ibus = 13 # distributed bus with high Q_loaing
id = "1" # no buses will have more than 1 shunt
status = 1 # all shunts operational
shunt_admittance_arr = [0.0,10.0] # [G,B], Bus 13 shunt can supply 19 MVAR of Q
ierr =  psspy.shunt_data(ibus, id, [status], shunt_admittance_arr) # call psspy library function
    
# Task 2: create a distributed generation profile

ibus = 2 # target generator
id = "1" # constant for all units
intgar = [1,1,0,0,0,0,0] # constant for all units
realar = [40.0,43.56,50.0,-40.0,10000.0,-10000.0,60.0,0.0,1.0,0.0,0.0,1.0,1.0,1.0,1.0,1.0,1.0] # argument syntax from API.pdf
ierr = psspy.machine_data_3(ibus, id, intgar, realar) # change Bus 2 dispatch

ibus = 3 # target generator
realar = [40.0,10.0,40.0,0.0,10000.0,-10000.0,60.0,0.0,1.0,0.0,0.0,1.0,1.0,1.0,1.0,1.0,1.0]
ierr = psspy.machine_data_3(ibus, id, intgar, realar) # change Bus 3 dispatch

ibus = 6 # target generator
realar = [15.0,10.0,40.0,0.0,10000.0,-10000.0,25.0,0.0,1.0,0.0,0.0,1.0,1.0,1.0,1.0,1.0,1.0]
ierr = psspy.machine_data_3(ibus, id, intgar, realar) # change Bus 6 dispatch

ibus = 8 # target generator
realar = [15.0,10.0,40.0,0.0,10000.0,-10000.0,25.0,0.0,1.0,0.0,0.0,1.0,1.0,1.0,1.0,1.0,1.0]
ierr = psspy.machine_data_3(ibus, id, intgar, realar) # change Bus 6 dispatch

# Task 3: re-dispactch the Bus 8 generator voltage to 1.0700 p.u.

ibus = 8 # target bus number
inode = 0
intgar = [0,0] # regulate generator voltage at its terminal bus (from API.pdf)
realar = [1.07,100.0]
ierr = psspy.plant_chng_4(ibus, inode, intgar, realar) # re-schedule Bus 8 voltage to 1.07 p.u.

# end of script
# running this script on ieee14bus.sav will generate modified_ieee14bus.sav